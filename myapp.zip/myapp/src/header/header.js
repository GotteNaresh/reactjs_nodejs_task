import React from 'react';
class Header extends React.Component {
   render() {
      return (
         <div class="header">
            <h1></h1>
         </div>
      );
   }
}
export default Header;