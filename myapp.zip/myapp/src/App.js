//import logo from './logo.svg';
import './App.css';
import Header from './header/header';
import Menus from './menus/menus';

function App() {
  return (
    <div className="App">
      <Header/>
      <Menus/>
    </div>
  );
}

export default App;
