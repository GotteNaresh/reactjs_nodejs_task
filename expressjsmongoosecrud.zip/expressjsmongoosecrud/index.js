const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const dotenv = require('dotenv');



const mongoose = require('mongoose');
// Import Routes
dotenv.config();
mongoose.connect(
    process.env.DB_CONNECT,
    { useNewUrlParser:true},
    () => console.log("connected to DB")
);
mongoose.connection
.once('open', () => console.log("connected"))
.on("error", error => {
    console.log("Your error"+error);
});

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));
 
// parse application/json
app.use(bodyParser.json());

const authRoute = require('./routes/auth');
// Router Middlewares
app.use(express.json());

app.use('/api/user', authRoute);



app.listen(3001, () => console.log("Server is Up and running"));

