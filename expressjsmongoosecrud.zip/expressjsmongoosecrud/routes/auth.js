const  router = require('express').Router();
const User = require("../model/User");
const fs = require('fs');
var base64 = require('base-64');
var request = require('request');
var url = require('url');


router.post('/register', async (req, res) => {
    console.log(req.body);
    const userNew = new User({
        name: req.body.name,
        email: req.body.email,
        password: req.body.password
    });
    try{
        console.log(userNew);
        const savedUser = await userNew.save();
        const getUser = await User.find();

        res.send(getUser);
    }catch(err){
        res.status(400).send(err);
    }
    //res.send("test");
});

router.get('/userslist', async (req, res) => {
    
    try{
        const getUser = await User.find();
        res.send(getUser);
    }catch(err){
        res.status(400).send(err);
    }
    //res.send("test");
});

router.get('/menuslist', async (req, res) => {
    
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    fs.readdir("./data/", (err, files) => {
        if (err)
          console.log(err);
        else {
          //console.log("\nCurrent directory filenames:");
          var menus = [];
          var i = 1;
          files.forEach(file => {
            console.log(file);
            menus.push({"id":i,"menu":file});
            i++;
          });
          setTimeout(function() {
            res.send(JSON.stringify(menus));
          },2000);
        }
      })
    
});


router.get('/filelist/:id', async (req, res) => {
    
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    //res.setHeader('Access-Control-Allow-Credentials', true);
    var folder = req.params.id;
    console.log(folder);
    fs.readdir("./data/"+folder, (err, files) => {
        if (err)
          console.log(err);
        else {
          //console.log("\nCurrent directory filenames:");
          var menus = [];
          var i = 1;
          files.forEach(file => {
            console.log(file);

            const stats = fs.statSync("./data/"+folder+'/'+file);
            const bytes = stats.size;
            var getfilesize = 0;
                if(bytes < 1024) getfilesize=bytes + " Bytes";
                else if(bytes < 1048576) getfilesize="KB:"+(bytes / 1024).toFixed(3) + " KB";
                else if(bytes < 1073741824) getfilesize="MB:"+(bytes / 1048576).toFixed(2) + " MB";
                else getfilesize=(bytes / 1073741824).toFixed(3) + " GB";
                menus.push({"id":i,"menu":file,"filesize":getfilesize});
            i++;
          });
          setTimeout(function() {
            res.send(JSON.stringify(menus));
          },2000);
        }
      })
    
});

module.exports = router;